import tkinter as tk

#Prices for different sections
section1 = 160
section2 = 120
section3 = 80
section4 = 40
tax = 1.07

#Sets up Window
def setup_window(title, width, height, bg_color, logo_path):
    root = tk.Tk()
    root.title(title)
    root.geometry(f'{width}x{height}')
    root.configure(bg=bg_color)

#Insert Logo
    photo = tk.PhotoImage(file=logo_path)
    new_width = 400
    new_height = 200
    photo = photo.subsample(int(photo.width() / new_width), int(photo.height() / new_height))

    labelp = tk.Label(root, image=photo)
    labelp.photo = photo  
    labelp.image = photo  
    labelp.place(relx=.5, rely=.65, anchor='center')

    return root
#Creates the final output display
def display_final_output(ticket_package, section, number_of_tickets, total):
    root = setup_window("Final Output", 1400, 1200, 'darkviolet', 'ECU_logo.png')

    final_output_label = tk.Label(
        root,
        text=f'You ordered {number_of_tickets} tickets with the {"Season" if ticket_package == 1 else "Individual"} package '
             f'in section {section} for ${total:,.2f}.',
        font=('Arial', 14),
        padx=20,
        pady=20
    )
    final_output_label.pack()

    root.mainloop()
#Sets up an error message display
def display_error_message(message, bg_color):
    root = tk.Tk()
    root.title("Error Message")
    root.geometry("400x200")
    root.configure(bg=bg_color)

    label = tk.Label(root, text=message, font=('Arial', 12), padx=20, pady=20, bg=bg_color)
    label.pack()

    root.mainloop()
#Function for customer choose which ticket package they want
def get_ticket_package():
    root = setup_window("ECU Ticket Order Form", 1400, 1200, 'darkviolet', 'ECU_logo.png')

    package_var = tk.StringVar()

    def check_input(event=None):
        try:
            package = int(entry.get())
            if package in [1, 2]:
                package_var.set(package)
                root.destroy()  # Close the Tkinter window if input is valid
            else:
                display_error_message("Invalid input. Please enter 1 or 2.", 'darkviolet')
        except ValueError:
            display_error_message("Invalid input. Please enter a number.", 'darkviolet')

    label = tk.Label(root, text="Please enter 1 for season tickets or 2 for individual tickets:")
    label.pack(pady=10)

    entry = tk.Entry(root)
    entry.pack(pady=10)
    entry.bind("<Return>", check_input)  

    error_label = tk.Label(root, text="", fg="red", bg='darkviolet')
    error_label.pack(pady=10)

    button = tk.Button(root, text="Submit", command=check_input)
    button.pack(pady=10)

    root.mainloop()

    return int(package_var.get())  
#Has customer choose the section they want
def get_section():
    root = setup_window("ECU Ticket Order Form", 1400, 1200, 'darkviolet', 'ECU_logo.png')

    section_var = tk.StringVar()

    def check_input(event=None):
        try:
            section_num = int(entry.get())
            if 1 <= section_num <= 4:
                section_var.set(section_num)
                root.destroy()  
            else:
                display_error_message("Invalid input. Please enter 1, 2, 3, or 4.", 'darkviolet')
        except ValueError:
            display_error_message("Invalid input. Please enter a number.", 'darkviolet')

    label = tk.Label(root, text="Please enter 1, 2, 3 or 4 for section number for the tickets that you wish to purchase:")
    label.pack(pady=10)

    entry = tk.Entry(root)
    entry.pack(pady=10)
    entry.bind("<Return>", check_input)  

    error_label = tk.Label(root, text="", fg="red", bg='darkviolet')
    error_label.pack(pady=10)

    button = tk.Button(root, text="Submit", command=check_input)
    button.pack(pady=10)

    root.mainloop()

    return int(section_var.get())  
#Has the customer pick how many seats they want
def get_number_of_tickets():
    root = setup_window("ECU Ticket Order Form", 1400, 1200, 'darkviolet', 'ECU_logo.png')

    num_tickets_var = tk.StringVar()

    def check_input(event=None):
        try:
            num_tickets = int(entry.get())
            if num_tickets > 0:
                num_tickets_var.set(num_tickets)
                root.destroy()  
            else:
                display_error_message("Invalid input. Please enter a positive number.", 'darkviolet')
        except ValueError:
            display_error_message("Invalid input. Please enter a number.", 'darkviolet')

    label = tk.Label(root, text="Please enter the number of tickets that you wish to purchase:")
    label.pack(pady=10)

    entry = tk.Entry(root)
    entry.pack(pady=10)
    entry.bind("<Return>", check_input)  

    error_label = tk.Label(root, text="", fg="red", bg='darkviolet')
    error_label.pack(pady=10)

    button = tk.Button(root, text="Submit", command=check_input)
    button.pack(pady=10)

    root.mainloop()

    return int(num_tickets_var.get())  
#Call on the functions earlier for User inputs
ticket_package = get_ticket_package()
section = get_section()
number_of_tickets = get_number_of_tickets()
#Determines what package is bought
if ticket_package == 1:
    total_number_of_games = 12
    ticket_type = 'Season'
else:
    total_number_of_games = 1
    ticket_type = 'Individual'
#Determines the section they are sitting in
if section == 1:
    section_price = section1
elif section == 2:
    section_price = section2
elif section == 3:
    section_price = section3
else:
    section_price = section4
#Calculates final total
cost_pretax = total_number_of_games * section_price * number_of_tickets
total = cost_pretax * (1 + tax)

#Display the final output in a new window
display_final_output(ticket_package, section, number_of_tickets, total)


 
